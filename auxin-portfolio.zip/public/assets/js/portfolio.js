/*! Auxin portfolio - v1.7.2 (2018-09-16)
 *  All required plugins 
 *  http://averta.net/phlox/
 */



/*! 
 * 
 * ================== public/assets/js/src/init.general.js =================== 
 **/ 

;(function($){
    // on document ready
    var filterList = $('.aux-widget-recent-portfolios .aux-ajax-filters li[data-filter]');

        filterList.on('click', function(e) {
            e.preventDefault();
            var $this   = $(this),
                $container = $this.parents('.aux-widget-recent-portfolios').find('.aux-ajax-view'),
                $ajaxSpinner = $this.parents('.aux-widget-recent-portfolios').find('.aux-items-loading');
                data = {
                    action  : 'aux_recent_portfolio_filter_content',
                    term    : $this.data('filter'),
                    taxonomy: $container.data('taxonomy'),
                    num     : $container.data('num'),
                    order   : $container.data('order'),
                    orderby : $container.data('orderby'),
                    n       : $container.data('n'),
                    args    : eval($container.data('element-id') + 'AjaxConfig')
                };

                $.post( auxpfo.ajax_url, data, function(res){

                    if ( res ) {

                        setTimeout(function() {
                            $container.AuxIsotope( 'removeAll' );
                            $newItems = $(res);

                            $newItems.each( function( index, element ) {
                                $item = $(element);
                                $container.AuxIsotope( 'insert', $item );
                            });

                            $container.find('.aux-hover-twoway').AuxTwoWayHover(); 
                            
                        }, 1000);
                    }

                });
                            
        });

})(jQuery);