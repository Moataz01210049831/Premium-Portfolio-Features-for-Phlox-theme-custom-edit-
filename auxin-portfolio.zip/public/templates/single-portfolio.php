<?php
/**
 * The Template for displaying all single portfolio
 *
 * 
 * @package    Auxin
 * @license    LICENSE.txt
 * @author     
 * @link       http://averta.net/phlox/
 * @copyright  (c) 2010-2018 
*/
global $post;
$is_pass_protected = post_password_required();

get_header(); ?>
<?php //include 'slider.php'; ?>

    <main id="main" <?php auxin_content_main_class(); ?> >
        <div class="aux-wrapper">
            <div class="aux-container aux-fold">

                <div id="primary" class="aux-primary" >
                    <div class="content" role="main"  >
<?php
                        if ( have_posts() && ! $is_pass_protected ) :

                            auxpfo_get_template_part( 'theme-parts/single', get_post_type() );

                            comments_template( '/comments.php', true );

                        elseif( $is_pass_protected ) :

                            echo get_the_password_form();

                        else:

                            auxpfo_get_template_part( 'theme-parts/content', 'none' );

                        endif;

                        do_action( 'auxin_portfolio_single_after_article_primary', $post );

                        



   $args = array(
	
	'post_type'        => 'portfolio',
	'orderby'=>'menu_order',
	 'sort_order'=>'asc',
     'posts_per_page'=>-1,
	'post_mime_type'   => '',
	'post_parent'      => '',
	'author'	   => '',
	'author_name'	   => '',
	'post_status'      => 'publish',
	'suppress_filters' => true,
	'fields'           => '',
);
         $postlist = get_posts($args);
$posts = array();
foreach ( $postlist as $post ) {
   $posts[] += $post->ID;

}

// print_r($posts);
end($posts);         // move the internal pointer to the end of the array
$key = key($posts);  // fetches the key of the element pointed to by the internal pointer


global $wp_query;


$current = array_search( $wp_query->post->ID, $posts );
// echo $current;
// echo $current-1;
$prevID = $posts[$current-1];
$nextID = $posts[$current+1];
?>
<?php   $my_current_lang = apply_filters( 'wpml_current_language', NULL ); 
// echo $my_current_lang;
    
?>

    <?php

  if ( $my_current_lang=='ar' ) {

      if ($current==0) {
        echo " ";
    }else{
          echo '<div class="navigation"><div class="alignleft" style=""><a href="' . get_permalink( $prevID ) . '"
             title="' . get_the_title( $prevID ) . '">';
             echo '<div class="trys" style="display: inline-block;
    padding-left: 15px;
    position: relative;
    top: 0px;">
                                <p class="np-nav-text" style="color:black;font-size: .75em;">السابق</p>
                                <h4 class="np-title" style="color:black;font-weight:600;font-size: 1.125em;">' . get_the_title($prevID) . '</h4></div><div class="np-arrow" style="display:inline-flex"><img width="80" height="80" src="' . get_the_post_thumbnail_url($prevID) . '" class="auxin-attachment auxin-featured-image attachment-80x80" style="height:80px" alt="3p" /><div class="aux-hover-slide aux-arrow-nav aux-outline" style="height:80px;">
                        <span class="aux-svg-arrow aux-medium-right"></span>
                        <span class="aux-hover-arrow aux-svg-arrow aux-medium-right"></span>
                    </div></div></div></div>';

};
}elseif($my_current_lang=='en'){

if ($current==0) {
        echo " ";
    }else{
          echo '<div class="navigation"><div class="alignleft" style=""><a href="' . get_permalink( $prevID ) . '"
             title="' . get_the_title( $prevID ) . '">';
             echo '<div class="np-arrow" style="display:inline-flex"><div class="aux-hover-slide aux-arrow-nav aux-outline" style="height:80px;">
                        <span class="aux-svg-arrow aux-medium-left"></span>
                        <span class="aux-hover-arrow aux-svg-arrow aux-medium-left"></span>
                    </div><img width="80" height="80" src="' . get_the_post_thumbnail_url($prevID) . '" class="auxin-attachment auxin-featured-image attachment-80x80" style="height:80px" alt="3p" />                </div><div class="trys" style="display: inline-block;
    padding-left: 15px;
    position: relative;
    top: 0px;">
                                <p class="np-nav-text" style="color:black;font-size: .75em;">PREV Protofolio</p>
                                <h4 class="np-title" style="color:black;font-weight:600;font-size: 1.125em;">' . get_the_title($prevID) . '</h4></div></div></div>';

};


}else{
    if ($current==0) {
        echo " ";
    }else{
          echo '<div class="navigation"><div class="alignleft" style=""><a href="' . get_permalink( $prevID ) . '"
             title="' . get_the_title( $prevID ) . '">';
             echo '<div class="np-arrow" style="display:inline-flex"><div class="aux-hover-slide aux-arrow-nav aux-outline" style="height:80px;">
                        <span class="aux-svg-arrow aux-medium-left"></span>
                        <span class="aux-hover-arrow aux-svg-arrow aux-medium-left"></span>
                    </div><img width="80" height="80" src="' . get_the_post_thumbnail_url($prevID) . '" class="auxin-attachment auxin-featured-image attachment-80x80" style="height:80px" alt="3p" />                </div><div class="trys" style="display: inline-block;
    padding-left: 15px;
    position: relative;
    top: 0px;">
                                <p class="np-nav-text" style="color:black;font-size: .75em;">ranije</p>
                                <h4 class="np-title" style="color:black;font-weight:600;font-size: 1.125em;">' . get_the_title($prevID) . '</h4></div></div></div>';

};

}
       // ============================

if ( $my_current_lang=='ar' ) {

if($current==$key){

    echo " ";
}else {
                                 echo '<div class="navigation"><div class="alignright" style=""><a href="' . get_permalink( $nextID ) . '"
             title="' . get_the_title( $nextID ) . '">';
             echo '<div class="np-arrow" style="display:inline-flex"><div class="aux-hover-slide aux-arrow-nav aux-outline" style="height:80px;">
                        <span class="aux-svg-arrow aux-medium-left"></span>
                        <span class="aux-hover-arrow aux-svg-arrow aux-medium-left"></span>
                    </div>
                                 <img width="80" height="80" src="' . get_the_post_thumbnail_url($nextID) . '" class="auxin-attachment auxin-featured-image attachment-80x80" style="height:80px" alt="3p" /><div style="display: inline-block;
    padding-left: 15px;
    position: relative;
    top: 0px;">
                                <p class="np-nav-text" style="color:black;font-size: .75em;"> التالى </p>
                                <h4 class="np-title" style="color:black;font-weight:600;font-size: 1.125em;">' . get_the_title($nextID) . '</h4></div>
                                   </div></div></div>';
};
}elseif($my_current_lang=='en'){

if($current==$key){

    echo " ";
}else {
                                 echo '<div class="navigation"><div class="alignright" style=""><a href="' . get_permalink( $nextID ) . '"
             title="' . get_the_title( $nextID ) . '">';
             echo '<div style="display: inline-block;
    padding-left: 15px;
    position: relative;
    top: 0px;">
                                <p class="np-nav-text" style="color:black;font-size: .75em;">NEXT Portfolio</p>
                                <h4 class="np-title" style="color:black;font-weight:600;font-size: 1.125em;">' . get_the_title($nextID) . '</h4></div><div class="np-arrow" style="display:inline-flex">
                                 <img width="80" height="80" src="' . get_the_post_thumbnail_url($nextID) . '" class="auxin-attachment auxin-featured-image attachment-80x80" style="height:80px" alt="3p" /><div class="aux-hover-slide aux-arrow-nav aux-outline" style="height:80px;">
                        <span class="aux-svg-arrow aux-medium-right"></span>
                        <span class="aux-hover-arrow aux-svg-arrow aux-medium-right"></span>
                    </div>
                                   </div></div></div>';
};

    }else{
        if($current==$key){

    echo " ";
}else {
                                 echo '<div class="navigation"><div class="alignright" style=""><a href="' . get_permalink( $nextID ) . '"
             title="' . get_the_title( $nextID ) . '">';
             echo '<div style="display: inline-block;
    padding-left: 15px;
    position: relative;
    top: 0px;">
                                <p class="np-nav-text" style="color:black;font-size: .75em;">sljedeće</p>
                                <h4 class="np-title" style="color:black;font-weight:600;font-size: 1.125em;">' . get_the_title($nextID) . '</h4></div><div class="np-arrow" style="display:inline-flex">
                                 <img width="80" height="80" src="' . get_the_post_thumbnail_url($nextID) . '" class="auxin-attachment auxin-featured-image attachment-80x80" style="height:80px" alt="3p" /><div class="aux-hover-slide aux-arrow-nav aux-outline" style="height:80px;">
                        <span class="aux-svg-arrow aux-medium-right"></span>
                        <span class="aux-hover-arrow aux-svg-arrow aux-medium-right"></span>
                    </div>
                                   </div></div></div>';
};
    }


?>



<!-- ================================================================================== -->









<!-- ============================== end of my function ========================================== -->
<?php              
                    global $post_next_prev_navigation;
                    echo empty( $post_next_prev_navigation ) ? '' : $post_next_prev_navigation;
?>
                </div><!-- end primary -->


                <?php get_sidebar(); ?>


            </div><!-- end container -->

        <?php do_action( 'auxin_portfolio_single_after_content_primary', $post ); ?>

        </div><!-- end wrapper -->
    </main><!-- end main -->

<?php get_sidebar('footer'); ?>
<?php get_footer(); ?>
